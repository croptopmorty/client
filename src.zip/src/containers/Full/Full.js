import React, {Component} from 'react';
import {Switch, Route, Redirect} from 'react-router-dom';
import {Container} from 'reactstrap';
import Header from '../../components/Header/';
import Sidebar from '../../components/Sidebar/';
import Breadcrumb from '../../components/Breadcrumb/';
import Aside from '../../components/Aside/';
import Footer from '../../components/Footer/';

import Dashboard from '../../views/Dashboard/';


import Charts from '../../views/Charts/';
import Cases from '../../views/Cases/Cases';
import Devices from '../../views/Devices/Devices';



class Full extends Component {
  render() {
    return (
      <div className="app">
        <Header/>
        <div className="app-body">
          <Sidebar {...this.props}/>
          <main className="main">
            <Breadcrumb/>
            <Container fluid>
              <Switch>
                <Route path="/dashboard"  name="dash"     component={Dashboard}/>
                <Route path="/charts"     name="Charts"   component={Charts}/>
                <Route path="/cases"      name="Cases"    component={Cases}/>
                <Route path="/devices"    name="Devices"  component={Devices}/>

                <Redirect from="/" to="/dashboard"/>
              </Switch>
            </Container>
          </main>
          <Aside/>
        </div>
        <Footer/>
      </div>
    );
  }
}

export default Full;
