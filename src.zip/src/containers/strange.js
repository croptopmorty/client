import React, {Component} from 'react';

class Strange extends Component{

    render(){
        return(

            <div className = "container">
                <div className = "row">
                    <div className = "col"/>
                    <div className="col-sm-4">
                        <h2> Truth is stranger than fiction</h2>
                    </div>
                    <div className="col"/>
                </div>
            </div>
        );
    }

}

export default Strange;