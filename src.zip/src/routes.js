const routes = {
  '/': 'Home',
  '/charts': 'Charts',
  '/dashboard': 'Dashboard'
};
export default routes;
