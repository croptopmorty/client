import React, {Component} from 'react';
import {
  Badge,
  Row,
  Col,
  Card,
  CardHeader,
  CardBody,
  Table,
  Pagination,
  PaginationItem,
  PaginationLink
} from 'reactstrap';


class Cases extends Component {
  render() {
    return (
      <div className="animated fadeIn">
        <Row>          
          <Col xs="12" lg="6">
            <Card>
              <CardHeader>
                <i className="fa fa-film"></i> Case6
              </CardHeader>
              <CardBody>
                <Table responsive striped>
                  <thead>
                  <tr>
                    <th>Device</th>
                    <th>Created</th>
                    <th>SystemInfo</th>
                    <th>Status</th>
                  </tr>
                  </thead>
                  <tbody>
                  <tr>
                    <td>Napier Grass</td>
                    <td>2012/01/01</td>
                    <td>Yiorgos Avraamu</td>
                    <td>
                      <Badge color="success">Active</Badge>
                    </td>
                  </tr>
                                    
                  
                  </tbody>
                </Table>
               
              </CardBody>
            </Card>
          </Col>
          <Col xs="12" lg="6">
            <Card>
              <CardHeader>
                <i className="fa fa-film"></i> Case5
              </CardHeader>
              <CardBody>
                <Table responsive striped>
                  <thead>
                  <tr>
                    <th>Device</th>
                    <th>Created</th>
                    <th>SystemInfo</th>
                    <th>Status</th>
                  </tr>
                  </thead>
                  <tbody>
                  <tr>
                    <td>Napier Grass</td>
                    <td>2012/01/01</td>
                    <td>Yiorgos Avraamu</td>
                    <td>
                      <Badge color="success">Active</Badge>
                    </td>
                  </tr>
                  <tr>
                    <td>Chocolate Tango</td>
                    <td>2012/02/01</td>
                    <td>Avram Tarasios</td>
                    <td>
                      <Badge color="danger">Disabled</Badge>
                    </td>
                  </tr>
                  <tr>
                    <td>Frankenstein's Fountains</td>
                    <td>2012/02/01</td>
                    <td>Quintin Ed</td>
                    <td>
                      <Badge color="secondary">Inactive</Badge>
                    </td>
                  </tr>
                  
                  </tbody>
                </Table>
              </CardBody>
            </Card>
          </Col>         
        </Row>
        
        <Row>          
          <Col xs="12" lg="6">
            <Card>
              <CardHeader>
                <i className="fa fa-film"></i> Case4
              </CardHeader>
              <CardBody>
                <Table responsive striped>
                  <thead>
                  <tr>
                    <th>Device</th>
                    <th>Created</th>
                    <th>SystemInfo</th>
                    <th>Status</th>
                  </tr>
                  </thead>
                  <tbody>
                  <tr>
                    <td>Napier Grass</td>
                    <td>2012/01/01</td>
                    <td>Yiorgos Avraamu</td>
                    <td>
                      <Badge color="success">Active</Badge>
                    </td>
                  </tr>
                  <tr>
                    <td>Chocolate Tango</td>
                    <td>2012/02/01</td>
                    <td>Avram Tarasios</td>
                    <td>
                      <Badge color="danger">Disabled</Badge>
                    </td>
                  </tr>
                  <tr>
                    <td>Frankenstein's Fountains</td>
                    <td>2012/02/01</td>
                    <td>Quintin Ed</td>
                    <td>
                      <Badge color="secondary">Inactive</Badge>
                    </td>
                  </tr>
                  <tr>
                    <td>Group Therapy</td>
                    <td>2012/03/01</td>
                    <td>Enéas Kwadwo</td>
                    <td>
                      <Badge color="warning">Pending</Badge>
                    </td>
                  </tr>
                  <tr>
                    <td>Centipede</td>
                    <td>2012/01/21</td>
                    <td>Agapetus Tadeáš</td>
                    <td>
                      <Badge color="success">Active</Badge>
                    </td>
                  </tr>
                  </tbody>
                </Table>               
              </CardBody>
            </Card>
          </Col>

          <Col xs="12" lg="6">
            <Card>
              <CardHeader>
                <i className="fa fa-film"></i> Case3
              </CardHeader>
              <CardBody>
                <Table responsive striped>
                  <thead>
                  <tr>
                    <th>Device</th>
                    <th>Created</th>
                    <th>SystemInfo</th>
                    <th>Status</th>
                  </tr>
                  </thead>
                  <tbody>
                  <tr>
                    <td>Yiorgos Avraamu</td>
                    <td>2012/01/01</td>
                    <td>Frankenstein's Fountain</td>
                    <td>
                      <Badge color="success">Active</Badge>
                    </td>
                  </tr>
                  <tr>
                    <td>Avram Tarasios</td>
                    <td>2012/02/01</td>
                    <td>Chocolate Tango</td>
                    <td>
                      <Badge color="danger">Disabled</Badge>
                    </td>
                  </tr>
                  <tr>
                    <td>Quintin Ed</td>
                    <td>2012/02/01</td>
                    <td>Admin</td>
                    <td>
                      <Badge color="secondary">Inactive</Badge>
                    </td>
                  </tr>
                  <tr>
                    <td>Enéas Kwadwo</td>
                    <td>2012/03/01</td>
                    <td>Centipede</td>
                    <td>
                      <Badge color="warning">Pending</Badge>
                    </td>
                  </tr>
                  <tr>
                    <td>Agapetus Tadeáš</td>
                    <td>2012/01/21</td>
                    <td>Napier Grass</td>
                    <td>
                      <Badge color="success">Active</Badge>
                    </td>
                  </tr>
                  </tbody>
                </Table>
              </CardBody>
            </Card>
          </Col>
        </Row>

        <Row>          
          <Col xs="12" lg="6">
            <Card>
              <CardHeader>
                <i className="fa fa-film"></i> Case2
              </CardHeader>
              <CardBody>
                <Table responsive striped>
                  <thead>
                  <tr>
                    <th>Device</th>
                    <th>Created</th>
                    <th>SystemInfo</th>
                    <th>Status</th>
                  </tr>
                  </thead>
                  <tbody>
                  <tr>
                    <td>Napier Grass</td>
                    <td>2012/01/01</td>
                    <td>Yiorgos Avraamu</td>
                    <td>
                      <Badge color="success">Active</Badge>
                    </td>
                  </tr>
                  <tr>
                    <td>Chocolate Tango</td>
                    <td>2012/02/01</td>
                    <td>Avram Tarasios</td>
                    <td>
                      <Badge color="danger">Disabled</Badge>
                    </td>
                  </tr>
                  <tr>
                    <td>Frankenstein's Fountains</td>
                    <td>2012/02/01</td>
                    <td>Quintin Ed</td>
                    <td>
                      <Badge color="secondary">Inactive</Badge>
                    </td>
                  </tr>
                  <tr>
                    <td>Group Therapy</td>
                    <td>2012/03/01</td>
                    <td>Enéas Kwadwo</td>
                    <td>
                      <Badge color="warning">Pending</Badge>
                    </td>
                  </tr>
                  <tr>
                    <td>Centipede</td>
                    <td>2012/01/21</td>
                    <td>Agapetus Tadeáš</td>
                    <td>
                      <Badge color="success">Active</Badge>
                    </td>
                  </tr>
                  </tbody>
                </Table>               
              </CardBody>
            </Card>
          </Col>

          <Col xs="12" lg="6">
            <Card>
              <CardHeader>
                <i className="fa fa-film"></i> Case1
              </CardHeader>
              <CardBody>
                <Table responsive striped>
                  <thead>
                  <tr>
                    <th>Device</th>
                    <th>Created</th>
                    <th>SystemInfo</th>
                    <th>Status</th>
                  </tr>
                  </thead>
                  <tbody>
                  <tr>
                    <td>Yiorgos Avraamu</td>
                    <td>2012/01/01</td>
                    <td>Frankenstein's Fountain</td>
                    <td>
                      <Badge color="success">Active</Badge>
                    </td>
                  </tr>
                  <tr>
                    <td>Avram Tarasios</td>
                    <td>2012/02/01</td>
                    <td>Chocolate Tango</td>
                    <td>
                      <Badge color="danger">Disabled</Badge>
                    </td>
                  </tr>
                  <tr>
                    <td>Quintin Ed</td>
                    <td>2012/02/01</td>
                    <td>Admin</td>
                    <td>
                      <Badge color="secondary">Inactive</Badge>
                    </td>
                  </tr>
                  <tr>
                    <td>Enéas Kwadwo</td>
                    <td>2012/03/01</td>
                    <td>Centipede</td>
                    <td>
                      <Badge color="warning">Pending</Badge>
                    </td>
                  </tr>
                  <tr>
                    <td>Agapetus Tadeáš</td>
                    <td>2012/01/21</td>
                    <td>Napier Grass</td>
                    <td>
                      <Badge color="success">Active</Badge>
                    </td>
                  </tr>
                  </tbody>
                </Table>
              </CardBody>
            </Card>
          </Col>
        </Row>

        <Row>
          <Col>
            <Card>
              <CardHeader>
                <i className="fa fa-film"></i> All Cases
              </CardHeader>
              <CardBody>
                <Table hover bordered striped responsive size="sm">
                  <thead>
                  <tr>
                    <th>Case</th>
                    <th>Date Created</th>
                    <th>Date Modified</th>
                    <th>Author</th>
                    <th>Status</th>
                  </tr>
                  </thead>
                  <tbody>
                  <tr>
                    <td>Vishnu Serghei</td>
                    <td>2012/01/01</td>
                    <td>2012/01/01</td>
                    <td>Folly Frey</td>
                    <td>
                      <Badge color="success">Active</Badge>
                    </td>
                  </tr>
                  <tr>
                    <td>Zbyněk Phoibos</td>
                    <td>2012/02/01</td>
                    <td>2012/02/01</td>
                    <td>NYS 2018</td>
                    <td>
                      <Badge color="danger">Disabled</Badge>
                    </td>
                  </tr>
                  <tr>
                    <td>Einar Randall</td>
                    <td>2012/02/01</td>
                    <td>2012/02/01</td>
                    <td>Shackton</td>
                    <td>
                      <Badge color="secondary">Inactive</Badge>
                    </td>
                  </tr>
                  <tr>
                    <td>Félix Troels</td>
                    <td>2012/03/01</td>
                    <td>2012/03/01</td>
                    <td>Bare knuckles</td>
                    <td>
                      <Badge color="warning">Pending</Badge>
                    </td>
                  </tr>
                  <tr>
                    <td>Aulus Agmundr</td>
                    <td>2012/01/21</td>
                    <td>2012/01/21</td>
                    <td>Five Finger Death Punch</td>
                    <td>
                      <Badge color="success">Active</Badge>
                    </td>
                  </tr>
                  <tr>
                    <td>Vishnu Serghei</td>
                    <td>2012/01/01</td>
                    <td>2012/01/01</td>
                    <td>Folly Frey</td>
                    <td>
                      <Badge color="success">Active</Badge>
                    </td>
                  </tr>
                  <tr>
                    <td>Zbyněk Phoibos</td>
                    <td>2012/02/01</td>
                    <td>2012/02/01</td>
                    <td>NYS 2018</td>
                    <td>
                      <Badge color="danger">Disabled</Badge>
                    </td>
                  </tr>
                  <tr>
                    <td>Einar Randall</td>
                    <td>2012/02/01</td>
                    <td>2012/02/01</td>
                    <td>Shackton</td>
                    <td>
                      <Badge color="secondary">Inactive</Badge>
                    </td>
                  </tr>
                  <tr>
                    <td>Félix Troels</td>
                    <td>2012/03/01</td>
                    <td>2012/03/01</td>
                    <td>Bare knuckles</td>
                    <td>
                      <Badge color="warning">Pending</Badge>
                    </td>
                  </tr>
                  <tr>
                    <td>Aulus Agmundr</td>
                    <td>2012/01/21</td>
                    <td>2012/01/21</td>
                    <td>Five Finger Death Punch</td>
                    <td>
                      <Badge color="success">Active</Badge>
                    </td>
                  </tr>
                  <tr>
                    <td>Vishnu Serghei</td>
                    <td>2012/01/01</td>
                    <td>2012/01/01</td>
                    <td>Folly Frey</td>
                    <td>
                      <Badge color="success">Active</Badge>
                    </td>
                  </tr>
                  <tr>
                    <td>Zbyněk Phoibos</td>
                    <td>2012/02/01</td>
                    <td>2012/02/01</td>
                    <td>NYS 2018</td>
                    <td>
                      <Badge color="danger">Disabled</Badge>
                    </td>
                  </tr>
                  <tr>
                    <td>Einar Randall</td>
                    <td>2012/02/01</td>
                    <td>2012/02/01</td>
                    <td>Shackton</td>
                    <td>
                      <Badge color="secondary">Inactive</Badge>
                    </td>
                  </tr>
                  <tr>
                    <td>Félix Troels</td>
                    <td>2012/03/01</td>
                    <td>2012/03/01</td>
                    <td>Bare knuckles</td>
                    <td>
                      <Badge color="warning">Pending</Badge>
                    </td>
                  </tr>
                  <tr>
                    <td>Aulus Agmundr</td>
                    <td>2012/01/21</td>
                    <td>2012/01/21</td>
                    <td>Five Finger Death Punch</td>
                    <td>
                      <Badge color="success">Active</Badge>
                    </td>
                  </tr>
                  <tr>
                    <td>Vishnu Serghei</td>
                    <td>2012/01/01</td>
                    <td>2012/01/01</td>
                    <td>Folly Frey</td>
                    <td>
                      <Badge color="success">Active</Badge>
                    </td>
                  </tr>
                  <tr>
                    <td>Zbyněk Phoibos</td>
                    <td>2012/02/01</td>
                    <td>2012/02/01</td>
                    <td>NYS 2018</td>
                    <td>
                      <Badge color="danger">Disabled</Badge>
                    </td>
                  </tr>
                  <tr>
                    <td>Einar Randall</td>
                    <td>2012/02/01</td>
                    <td>2012/02/01</td>
                    <td>Shackton</td>
                    <td>
                      <Badge color="secondary">Inactive</Badge>
                    </td>
                  </tr>
                  <tr>
                    <td>Félix Troels</td>
                    <td>2012/03/01</td>
                    <td>2012/03/01</td>
                    <td>Bare knuckles</td>
                    <td>
                      <Badge color="warning">Pending</Badge>
                    </td>
                  </tr>
                  <tr>
                    <td>Aulus Agmundr</td>
                    <td>2012/01/21</td>
                    <td>2012/01/21</td>
                    <td>Five Finger Death Punch</td>
                    <td>
                      <Badge color="success">Active</Badge>
                    </td>
                  </tr>
                  </tbody>
                </Table>
                <nav>
                  <Pagination>
                    <PaginationItem><PaginationLink previous href="#">Prev</PaginationLink></PaginationItem>
                    <PaginationItem active>
                      <PaginationLink href="#">1</PaginationLink>
                    </PaginationItem>
                    <PaginationItem><PaginationLink href="#">2</PaginationLink></PaginationItem>
                    <PaginationItem><PaginationLink href="#">3</PaginationLink></PaginationItem>
                    <PaginationItem><PaginationLink href="#">4</PaginationLink></PaginationItem>
                    <PaginationItem><PaginationLink next href="#">Next</PaginationLink></PaginationItem>
                  </Pagination>
                </nav>
              </CardBody>
            </Card>
          </Col>
        </Row>
      </div>

    )
  }
}

export default Cases;
